using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace kalkulator_podatku_dochodowego.Pages.Home
{
    public class HistoryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
