﻿using Microsoft.AspNetCore.Mvc;

namespace TaxCalculatorApp.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult History()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CalculateTax(decimal income)
        {
            decimal tax = income * 0.19m; // Przykładowa stawka podatku 19%
            ViewBag.Tax = tax;
            ViewBag.Income = income;
            return View("Index");
        }
    }
}
